<?php
$page = 'Home';
$pageDesc = '""';
include 'includes/header.php';
$page = 'home';
?>



    <!--banner sec start-->
    <section class="boba-tea-sec cat-shop">
        <img src="./images/hid6.png" class="hid6">
        <img src="./images/hid7.png" class="hid7">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="boba-tea-txt">
                        <h3>Lets get some</h3>
                        <h2>Accessories</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua.</p>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="boba-tea-img">
                        <img src="./images/cat-shop-ban1.png">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--banner sec end-->
    <!-- our product sec start -->
    <section class="product-sec">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-12">
                    <div class="sec-head">
                        <h2>our products</h2>
                    </div>
                    <div class="row mt-5">
                        <div class="col-12 col-lg-3 col-md-6">
                            <div class="prod">
                                <div class="prod-img">
                                    <img src="./images/prod1.png">
                                </div>
                                <div class="prod-desc">
                                    <div>
                                        <h3>product name</h3>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <span>(5.0)</span>
                                        </span>
                                    </div>
                                    <p>$10.00</p>
                                </div>
                                <div class="prod-desc-lo">
                                    <p>Lorem ipsum dummy</p>
                                    <a href="#" class="theme-btn"> buy now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-3 col-md-6">
                            <div class="prod">
                                <div class="prod-img">
                                    <img src="./images/prod2.png">
                                </div>
                                <div class="prod-desc">
                                    <div>
                                        <h3>product name</h3>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <span>(5.0)</span>
                                        </span>
                                    </div>
                                    <p>$10.00</p>
                                </div>
                                <div class="prod-desc-lo">
                                    <p>Lorem ipsum dummy</p>
                                    <a href="#" class="theme-btn"> buy now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-3 col-md-6">
                            <div class="prod">
                                <div class="prod-img">
                                    <img src="./images/prod3.png">
                                </div>
                                <div class="prod-desc">
                                    <div>
                                        <h3>product name</h3>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <span>(5.0)</span>
                                        </span>
                                    </div>
                                    <p>$10.00</p>
                                </div>
                                <div class="prod-desc-lo">
                                    <p>Lorem ipsum dummy</p>
                                    <a href="#" class="theme-btn"> buy now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-3 col-md-6">
                            <div class="prod">
                                <div class="prod-img">
                                    <img src="./images/prod4.png">
                                </div>
                                <div class="prod-desc">
                                    <div>
                                        <h3>product name</h3>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <span>(5.0)</span>
                                        </span>
                                    </div>
                                    <p>$10.00</p>
                                </div>
                                <div class="prod-desc-lo">
                                    <p>Lorem ipsum dummy</p>
                                    <a href="#" class="theme-btn"> buy now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-12 col-lg-3 col-md-6">
                            <div class="prod">
                                <div class="prod-img">
                                    <img src="./images/prod5.png">
                                </div>
                                <div class="prod-desc">
                                    <div>
                                        <h3>product name</h3>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <span>(5.0)</span>
                                        </span>
                                    </div>
                                    <p>$10.00</p>
                                </div>
                                <div class="prod-desc-lo">
                                    <p>Lorem ipsum dummy</p>
                                    <a href="#" class="theme-btn"> buy now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-3 col-md-6">
                            <div class="prod">
                                <div class="prod-img">
                                    <img src="./images/prod6.png">
                                </div>
                                <div class="prod-desc">
                                    <div>
                                        <h3>product name</h3>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <span>(5.0)</span>
                                        </span>
                                    </div>
                                    <p>$10.00</p>
                                </div>
                                <div class="prod-desc-lo">
                                    <p>Lorem ipsum dummy</p>
                                    <a href="#" class="theme-btn"> buy now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-3 col-md-6">
                            <div class="prod">
                                <div class="prod-img">
                                    <img src="./images/prod8.png">
                                </div>
                                <div class="prod-desc">
                                    <div>
                                        <h3>product name</h3>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <span>(5.0)</span>
                                        </span>
                                    </div>
                                    <p>$10.00</p>
                                </div>
                                <div class="prod-desc-lo">
                                    <p>Lorem ipsum dummy</p>
                                    <a href="#" class="theme-btn"> buy now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-3 col-md-6">
                            <div class="prod">
                                <div class="prod-img">
                                    <img src="./images/prod9.png">
                                </div>
                                <div class="prod-desc">
                                    <div>
                                        <h3>product name</h3>
                                        <span>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <span>(5.0)</span>
                                        </span>
                                    </div>
                                    <p>$10.00</p>
                                </div>
                                <div class="prod-desc-lo">
                                    <p>Lorem ipsum dummy</p>
                                    <a href="#" class="theme-btn"> buy now</a>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="row mt-5 justify-content-center">
                        <div class="col-6 col-lg-3 col-md-6 col-sm-9 text-center">
                            <a href="javasript" class="theme-btn view-all" >View All Products</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- our product sec end -->
    <!-- testimonial sec start -->
    <section class="testimonial-sec">
        <div class="container">
            <div class="sec-head">
                <h3>Testimonials</h3>
                <h2>What Our Clients Say About Us</h2>
            </div>
            <div class="row">
                <div class="col-12 col-lg-12">
                    <div class="testi-slider">
                        <div class="testi-slide">
                            <img src="./images/testi.png">
                            <div class="">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur harum iure
                                    natus quod sunt esse placeat totam perferendis dolor consequatur.</p>
                                <div>
                                    <h3>Bing Chilling</h3>
                                    <span>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="testi-slide">
                            <img src="./images/testi.png">
                            <div class="">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur harum iure
                                    natus quod sunt esse placeat totam perferendis dolor consequatur.</p>
                                <div>
                                    <h3>Bing Chilling</h3>
                                    <span>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="testi-slide">
                            <img src="./images/testi.png">
                            <div class="">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur harum iure
                                    natus quod sunt esse placeat totam perferendis dolor consequatur.</p>
                                <div>
                                    <h3>Bing Chilling</h3>
                                    <span>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- testimonial sec end -->

<?php
include 'includes/secfooter.php';
$page = 'home';
?>

<script>
    $('.testi-slider').slick({
        dots: true,
        infinite: true,
        arrows: true,
        speed: 300,
        slidesToShow: 2,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true,
                    arrows: false,

                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: false,
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: false,
                }
            }
        ]
    });

</script>