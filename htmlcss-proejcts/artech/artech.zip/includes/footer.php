<section>
        <footer class="text-white text-center text-lg-start sports-footer sports-footer-bg" id="footer">
            <!-- Grid container -->
            <div class="container p-4">
                <!--Grid row-->
                <div class="row">
                    <!--Grid column-->
                    <div class="col-lg-5 col-md-12 mb-4 mb-md-0 FC-1">
                        <img src="images/logo.png" alt="ARTEC">
                        <p>
                            Lorem Ipsum is simply dummy text of
                            the printing and typesetting industry.
                            Lorem Ipsum has been the industry's
                            standard dummy text ever since the
                            1500s, when an unknown.
                        </p>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-3 col-md-6 mb-4 mb-md-0 FC-2">
                        <h3>Service Type</h3>

                        <ul class="list-unstyled mb-0">
                            <li>
                                <a href="#!" class="text-white">Remodeling</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white">ADU</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white">Contractor Referral</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white">Feedback</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white">Others Contractors</a>
                            </li>
                        </ul>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-3 col-md-6 mb-4 mb-md-0 FC-3">

                        <h3 class="t">Quick Links</h3>

                        <ul class="list-unstyled mb-0">
                            <li>
                                <a href="#!" class="text-white">3d design
                                </a>
                            </li>
                            <li>
                                <a href="#!" class="text-white">our project</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white">investor and finance</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white">sell or buy project</a>
                            </li>
                        </ul>
                    </div>
                    <!--Grid column-->
                    <!--Grid column-->

                    <!--Grid column-->

                </div>
                <!--Grid row-->
                <div class="row">
                    <div class="col-lg-12 col-md-6 mb-4 mb-md-0">
                        <div class="fs-copyright">
                            <p>Copy right 2023 Lorem Ipsum , All Rights Reserved</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Grid container -->
        </footer>
    </section>
<script src="js/jquery-3.6.3.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/fancybox.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script type="text/javascript" src="js/slick.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
<script src="js/custom.js"></script>
</body>


</html>